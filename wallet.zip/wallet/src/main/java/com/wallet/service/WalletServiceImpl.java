package com.wallet.service;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {
	WalletDao walletDao=new WalletDaoImpl();
	@Override
	public long createAccount(Wallet w) throws WalletException {
		
		
		return walletDao.createAccount(w);
	}

	@Override
	public boolean validateWallet(Wallet w) throws WalletException {
	
		if(validateName(w.getName()) && validateMobile(w.getMobile()) && validateAddress(w.getAddress()) && validateAccType(w.getAccType()) && validateGender(w.getGender()) && validateAge(w.getAge())) {
			return true;
		}
		
		return false;
	}
	private boolean validateAge(String age) throws WalletException{
		if(age.isEmpty() || age==null ) {
			
			throw new WalletException("Invalid Age");
		}
		
		else if(age.matches("[a-zA-Z]{1,}")){
		
			
			throw new WalletException("Invalid Age");
		
	  }	
		else if( Integer.parseInt(age)<0 || Integer.parseInt(age)>=120)
		{
			throw new WalletException("Invalid Age");
		}
	
		return true;
		
	}

	private boolean validateGender(String gender) throws WalletException {
		 if(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female")|| gender.equalsIgnoreCase("others"))
				return true;
			 else
				 throw new WalletException("Invalid gender");
			
	}

	private boolean validateAccType(String accType) throws WalletException {
	 if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
		return true;
	 else
		 throw new WalletException("Account type should be savings or current");
	
	}

	private boolean validateAddress(String address) throws WalletException {
		if(address.isEmpty()|| address==null) {
    		
				throw new WalletException("Address is mandatory");
			
    	}
		return true;
	}

	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
		throw new WalletException("Customer Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z ][A-Za-z ]{2,}")) {
				throw new WalletException("Name should start with a Capital letter followed by a minimum of two characters");
				
			}
		}
		return true;
	}
	 private boolean validateMobile(String mobile) throws WalletException{
	    	if(mobile.isEmpty()|| mobile==null) {
	    		throw new WalletException("Mobile number is mandatory");
	    	}
	    	else {
	    		if(!mobile.matches("\\d{10}")) {
	    			throw new WalletException("Mobile number should contain only 10 digits");
	    		}
	    	}
			return true;
	    	
	    }

	@Override
	public boolean validatePin(String pin1) throws WalletException  {
		if(pin1.isEmpty()|| pin1==null) {
    		throw new WalletException("Pin number is mandatory");
    	}
    	else {
    		if(!pin1.matches("\\d{4}")) {
    			throw new WalletException("Pin number should contain only 4 digits");
    		}
    	}
		
		return true;
	}

	@Override
	public long getBalance(long num) throws WalletException {
		return walletDao.getBalance(num);
	}

	@Override
	public boolean deposit(long num, double amount) throws WalletException {
		
			
			return walletDao.deposit(num,amount);
		
	}

	@Override
	public boolean withdraw(long num, double amount) throws WalletException {
		return walletDao.withdraw(num,amount);

	}

	@Override
	public boolean fundTransfer(long acc1, long acc2, double amount) throws WalletException {
		
		return  walletDao.fundTransfer(acc1,acc2,amount);
	}

	@Override
	public boolean printTransactions(long acc,String pin) throws WalletException {
		
		return walletDao.printTranscations(acc, pin);
	}
}
