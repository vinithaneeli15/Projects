package com.wallet.service;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public interface WalletService {
	 long createAccount(Wallet w) throws WalletException;
	 boolean validateWallet(Wallet w) throws WalletException;
	boolean validatePin(String pin1)throws WalletException;
	long getBalance(long num) throws WalletException;
	 
	boolean deposit(long num, double amount)throws WalletException;
	boolean withdraw(long num, double amount)throws WalletException;
	boolean fundTransfer(long acc1,long acc2, double amount)throws WalletException;
	boolean printTransactions(long acc,String pin)throws WalletException;


}
