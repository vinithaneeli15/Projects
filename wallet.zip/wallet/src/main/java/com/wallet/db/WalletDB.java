package com.wallet.db;

import java.util.HashMap;
import java.util.List;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;

public class WalletDB {
	private static HashMap<Long,Wallet>
	
	 walletMap=new HashMap<Long,Wallet>();
	static {
		walletMap.put(12345678911l,new Wallet(12345678911l,"Mark","Savings","9087654321","34","male","7391","MWC city",89000));
		walletMap.put(12345678912l,new Wallet(12345678912l,"Pam","Savings","9898989898","24","male","7392","Sipcot,Chennai",78000));
		walletMap.put(12345678913l,new Wallet(12345678913l,"Sara","Current","7777777777","25","female","7393","Tambaram,Chennai",67000));
		walletMap.put(12345678914l,new Wallet(12345678914l,"Ben","Current","6666666666","56","male","7394","Jubliee hills,Hyderabad",59000));
		walletMap.put(12345678915l,new Wallet(12345678915l,"Anil","Savings","9898989898","45","male","7395","Bangalore",78909));
		walletMap.put(12345678916l,new Wallet(12345678916l,"Sunil","Current","6767676767","36","male","7396","Chengalpattu",98000));
	}
	public static HashMap<Long, Wallet> getWalletMap() {
		return walletMap;
	}
	 
	private static HashMap<Integer,Transaction>
	transactionMap=new HashMap<Integer,Transaction>();
	public static HashMap<Integer, Transaction> getTransactionMap() {
		return transactionMap;
	}
	
	
}
