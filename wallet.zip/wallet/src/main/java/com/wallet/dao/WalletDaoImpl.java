package com.wallet.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	 static HashMap<Long,Wallet> walletMap=WalletDB.getWalletMap();
	 static HashMap<Integer, Transaction> transactionMap=WalletDB.getTransactionMap();
	@Override
	public long createAccount(Wallet w) throws WalletException {
		//int pin=0;
		try {
			if(walletMap.size()==0) {
				w.setAccId(12345678911l);
				
			}
			else {
				Optional<Long> id=walletMap.keySet().stream().max(new Comparator<Long>() {
					@Override
					public int compare(Long x, Long y) {
						return x>y?1:x<y?-1:0;
					}
				});
				
				long reqid=id.get()+1;
				w.setAccId(reqid);
				//pin=walletMap.size()+7391;
				
			}
			walletMap.put(w.getAccId(),w);
			//w.setPin(pin);
			return w.getAccId();
		}
		catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
		
		
	}
	@Override
	public long getBalance(long num) throws WalletException {
		try {
			Wallet wallet=walletMap.get(num);
			
			if(wallet==null) {
				throw new WalletException("Customer with the account number "+num+
						"  is not available");
				
			}
			long bal=walletMap.get(num).getBalance();
			return bal;
		}
		catch (WalletException ex) {
			throw new WalletException(ex.getMessage());
		}
	}
	@Override
	public boolean deposit(long num, double amount) throws WalletException {

		try {
			Wallet w=walletMap.get(num);
			
			if(w==null) {
				throw new WalletException("Invalid id");
				
			}
			else
			{
				double amount1=walletMap.get(num).getBalance();
				amount1=amount1+amount;
				w.setBalance(amount1);
				walletMap.replace(w.getAccId(), w);
			}
		}
	catch (WalletException e) {
		throw new WalletException(e.getMessage());
	}
		return true;

	}
	@Override
	public boolean withdraw(long num, double amount) throws WalletException {
		try {
			Wallet w=walletMap.get(num);
			
			if(w==null) {
				throw new WalletException("Invalid Account Number");
				
			}
			else
			{
				double amount1=walletMap.get(num).getBalance();
				if(amount1<amount) {
					System.out.println("Insufficient balance");
				}
				else {
				double finalamount=amount1-amount;
				w.setBalance(finalamount);
				walletMap.replace(w.getAccId(), w);
				}
			}
		}
	catch (WalletException e) {
		throw new WalletException(e.getMessage());
	}
		return true;
	}
	@Override
	public boolean fundTransfer(long acc1, long acc2, double amount) throws WalletException {
		try {
			Wallet w=walletMap.get(acc1);
			Wallet w1=walletMap.get(acc2);
			if(w==null || w1==null) {
				throw new WalletException("Invalid Account Number");
				
			}
			else
			{
				double amount1=walletMap.get(acc1).getBalance();
				if(amount1<amount) {
					System.out.println("Insufficient balance");
					return false;
				}
				else {
				double finalamount1=amount1-amount;
				w.setBalance(finalamount1);
				walletMap.replace(w.getAccId(), w);
				double amount2=walletMap.get(acc2).getBalance();
				//System.out.println(amount2);
				double finalamount2=amount2+amount;
				w1.setBalance(finalamount2);
				walletMap.replace(w1.getAccId(), w1);
				}
			}
		}
	catch (WalletException e) {
		throw new WalletException(e.getMessage());
	}
		return true;
	}
	@Override
	public boolean printTranscations(long acc,String pin) throws WalletException {
		

			try {
							Wallet customer=walletMap.get(acc);
							
							if(customer==null) {
								throw new WalletException("customer with the account number "+acc+" Not existed");
							}
							if(!customer.getPin().equalsIgnoreCase(pin)) {
								throw new WalletException("Invalid pin number");
							}
							else {
								
								for(int key=1;key<=transactionMap.size();key++) {
									Transaction tr=transactionMap.get(key);
									if(tr.getAccNum()==acc) {
										System.out.println(tr);
									}

									}
								
							} 

	}catch (WalletException e) {
		
		throw new WalletException(e.getMessage());
	
	}
			return false;
	}
}
