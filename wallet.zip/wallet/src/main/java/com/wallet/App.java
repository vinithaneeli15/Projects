package com.wallet;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

public class App {
WalletService walletservice=new WalletServiceImpl();
static HashMap<Long,Wallet> walletMap=WalletDB.getWalletMap();
static HashMap<Integer, Transaction> transactionMap=WalletDB.getTransactionMap();

int transId=0;
		Scanner scan=new Scanner(System.in);
	    public static void main( String[] args ) throws WalletException 
	    {
	    	App a=new App();
			 a.scan.useDelimiter("\n");
			String option=null;
			while(true) {
			System.out.println("=======Wallet Appication=======");
			System.out.println("1. Create account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
			System.out.println("Enter your choice");
			option=a.scan.nextLine();
			switch(option) {
			case "1":
				a.createAccount();
				break;
			case "2":
				a.getBalance();
				break;
			case "3":
				a.deposit();
				break;
			case "4":
				a.withdraw();
				break;
			case "5":
			    a.fundTransfer();
				break;
			case "6":
				a.printTransactions();
				break;
			case "7":
				System.exit(0);
				break;	
			default:
				System.out.println("Enter valid option within 1 and 7");
				break;
			}
		  }

	}
	    public void createAccount() {
	    	Wallet w=new Wallet();
	    	System.out.println("Enter customer name");
			w.setName(scan.nextLine());
			System.out.println("Enter customer Mobile");
			w.setMobile(scan.nextLine());
			System.out.println("Enter customer age");
			w.setAge(scan.nextLine());
			System.out.println("Enter customer gender");
			w.setGender(scan.nextLine());
			System.out.println("Enter customer address");
			w.setAddress(scan.nextLine());
			System.out.println("Enter Account type");
			w.setAccType(scan.nextLine());
			System.out.println("Enter amount");
			w.setBalance(Double.parseDouble(scan.nextLine()));
			try {
				
				boolean result=walletservice.validateWallet(w);
				if(result) {
					long ret=walletservice.createAccount(w);
					System.out.println("Customer with account number "+ret+" created successfully");
					System.out.println("Set your pin number : ");
					String pin1=scan.nextLine();
					boolean result1=walletservice.validatePin(pin1);
					if(result1) {
						w.setPin(pin1);
						System.out.println("Pin has been set successfully");
					}
					
				}
			}
			catch (WalletException e) {
				System.err.println("An Error Occured : "+e.getMessage());
				System.out.println();
				
			}
	    }
		private void getBalance()   {
			System.out.println("Enter customer account number");
			long num=Long.parseLong(scan.nextLine());
			 Wallet wallet=walletMap.get(num);
		    System.out.println("Enter pin(4 digits)");
			String pin=scan.nextLine();
			 
			try {
				 if(wallet==null) 
					{
							throw new WalletException("Customer with the account number "+num+
									"  is not available");
						
					}
				String pin1=walletMap.get(num).getPin();
				if(pin.equals(pin1)) {
				long bal=walletservice.getBalance(num);
				String name=walletMap.get(num).getName();
				System.out.println("Customer Name : "+name);
				System.out.println("Customer Account Number : "+num);
				System.out.println("Balance : "+bal);
				}
				else
					System.out.println("Invalid pin");
			} catch (WalletException e) {
				
				System.err.println("An Error Occured : "+e.getMessage());
				System.out.println();
			}
				
		}
			
		private void deposit()  {
			System.out.println("Enter account number");
			long num=Long.parseLong(scan.nextLine());
			System.out.println("Enter pin(4 digits)");
			String pin=scan.nextLine();
       Wallet wallet=walletMap.get(num);

			
			 try {
				 if(wallet==null) 
					{
							throw new WalletException("Customer with the account number "+num+
									"  is not available");
						
					}
				 String pin1=walletMap.get(num).getPin();
					if(pin.equals(pin1)) {
				 System.out.println("Enter deposit amount");
					double amount=Double.parseDouble(scan.nextLine());
					boolean res=walletservice.deposit(num, amount);
						if(res) {
						System.out.println("Customer with account number "+num+" money deposited successfully");
						System.out.println("Customer Name : "+walletMap.get(num).getName());
						System.out.println("Balance : "+walletMap.get(num).getBalance());
						Transaction tr=transactionMap.get(num);
						transId++;
						LocalDateTime date=LocalDateTime.now();
						transactionMap.put(transId,new Transaction(num,"Deposit", amount,date) );
						
						
					}
					else
						System.out.println("Invalid pin");
					}
			 }
				catch (WalletException e) {
					System.err.println("An Error Occured : "+e.getMessage());
					System.out.println();
					
				}
		}
		public void withdraw() {
			System.out.println("Enter account number");
			long num=Long.parseLong(scan.nextLine());
			System.out.println("Enter pin(4 digits)");
			String pin=scan.nextLine();
			 Wallet wallet=walletMap.get(num);
			 try {
				 if(wallet==null) 
					{
							throw new WalletException("Customer with the account number "+num+
									"  is not available");
						
					}
				 String pin1=walletMap.get(num).getPin();
					if(pin.equals(pin1)) {
				 System.out.println("Enter withdrawal amount");
					double amount=Double.parseDouble(scan.nextLine());
					boolean res=walletservice.withdraw(num, amount);
						if(res) {
						System.out.println("Customer Name : "+walletMap.get(num).getName());
						System.out.println("Customer Account Number : "+num);
						System.out.println("Balance : "+walletMap.get(num).getBalance());
						Transaction tr=transactionMap.get(num);
					    transId++;
						LocalDateTime date=LocalDateTime.now();
						transactionMap.put(transId,new Transaction(num,"Withdrawal", amount,date) );
						
						
					}
					
				}
					else
						System.out.println("Invalid pin");
			 }
				catch (WalletException e) {
					System.err.println("An Error Occured : "+e.getMessage());
					System.out.println();
					
				}
		}
		public void fundTransfer() {
			System.out.println("Enter your Account Number");
			long acc1=Long.parseLong(scan.nextLine());
			System.out.println("Enter pin(4 digits)");
			String pin=scan.nextLine();
			try {
				Wallet w=walletMap.get(acc1);
				if(w==null)
					throw new WalletException("Invalid Account Number");
			String pin1=walletMap.get(acc1).getPin();
			 if(pin1.equals(pin)) {
				 System.out.println("Enter Account Number to which money to be deposited");
				 long acc2=Long.parseLong(scan.nextLine());
				 System.out.println("Enter amount");
					double amount=Double.parseDouble(scan.nextLine());
					boolean res=walletservice.fundTransfer(acc1,acc2, amount);
					if(res) {
						System.out.println("Money transferred successfully");
						System.out.println("Customer Name : "+walletMap.get(acc1).getName());
						System.out.println("Customer Account Number : "+acc1);
						System.out.println("Balance : "+walletMap.get(acc1).getBalance());
						Transaction tr=transactionMap.get(acc1);
						transId++;
						LocalDateTime date=LocalDateTime.now();
						transactionMap.put(transId,new Transaction( acc1,"Fund Transfer", amount,date) );
						
						}
						}
			 else
					System.out.println("Invalid pin");
			}catch (WalletException e) {
				System.err.println("An Error Occured : "+e.getMessage());
				System.out.println();
			}
		}
		public void printTransactions()  {
			
			System.out.println("Enter Account Number");
			long acc=Long.parseLong(scan.nextLine());
			System.out.println("Enter pin number");
			String pin=scan.nextLine();
			
			try {
				boolean b=walletservice.printTransactions(acc,pin);
				
			} catch (WalletException e) {
				System.err.println("An Error Occured : "+e.getMessage());
				System.out.println();
			}
			

		}
	  
}
