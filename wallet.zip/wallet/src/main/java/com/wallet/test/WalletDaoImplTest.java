package com.wallet.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	
	WalletDao dao=null;
	@Before
	public void setup() {
		dao=new WalletDaoImpl();
	}
	
	@After
	public void tearDown() {
		dao = null;
	}
	

	@Test
	public void testCreateAccount() {
		Wallet c = new Wallet();
		c.setAccId(1009);
		c.setName("Lavanya");
		c.setMobile("1234567890");
		
		c.setAddress("Pune");
		c.setBalance(200000);
		c.setPin("2123");
		
		
		try {
			dao.createAccount(c);
			double c1=dao.getBalance(12345678912l);
			assertNotNull(c1);
		} catch (WalletException e) {
			
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testShowBalance() {
		try {
			long c = dao.getBalance(12345678913l);
			assertNotNull(c);
			long c1 = dao.getBalance(12345678920l);
			assertNull(c1);
		} catch (WalletException e) {
			
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testDepositPositive() {
		try {
			assertEquals(true, dao.deposit(12345678913l, 20000));
		} catch (WalletException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testWithdrawPositive() {
		try {
			assertEquals(true, dao.withdraw(12345678913l, 20000));
		} catch (WalletException e) {
		
			e.printStackTrace();
		}
	}
	
	@Test
	public void testFundTransferPositive() {
		try {
			assertEquals(true, dao.deposit(12345678912l, 20000));
			assertEquals(true, dao.withdraw(12345678915l, 20000));
		} catch (WalletException e) {
			
			e.printStackTrace();
		}
	}
	@Test
	public void testPrintTransaction() {
	try {
		boolean b=dao.printTranscations(12345678913l,"7393");
		assertNotNull(b);
	} catch (WalletException e) {
		
		e.printStackTrace();
	}
	}
	
	



}
