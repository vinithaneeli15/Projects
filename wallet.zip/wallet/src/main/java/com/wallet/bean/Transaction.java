package com.wallet.bean;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class Transaction {
 private int transId;
 private long accNum;
 public int getTransId() {
	return transId;
}
public void setTransId(int transId) {
	this.transId = transId;
}
private String transactionType;
 private double amount;
 private LocalDateTime date;
 public Transaction() {
	super();
}
public Transaction(long accNum,String transactionType, double amount, LocalDateTime date) {
	super();
	this.accNum=accNum;
	this.transactionType = transactionType;
	this.amount = amount;
	this.date = date;
}
public long getAccNum() {
	return accNum;
}
public void setAccNum(long accNum) {
	this.accNum = accNum;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public LocalDateTime getDate() {
	return date;
}
public void setDate(LocalDateTime date) {
	this.date = date;
}
@Override
public String toString() {
	return "Transaction Type : " + transactionType + ", Amount : " + amount+", Date : "+date;
			}
 
}
