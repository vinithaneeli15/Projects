package com.wallet.dao;

import java.util.List;

import com.wallet.bean.Transaction;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public interface WalletDao {
	long createAccount(Wallet w) throws WalletException;
	long getBalance(long num) throws WalletException;
	boolean deposit(long num,double amount) throws WalletException;
	boolean withdraw(long num, double amount)throws WalletException;
	boolean fundTransfer(long acc1,long acc2, double amount)throws WalletException;
	boolean printTranscations(long acc,String pin) throws WalletException;


}
