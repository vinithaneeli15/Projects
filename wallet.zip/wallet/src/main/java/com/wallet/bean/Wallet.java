package com.wallet.bean;

public class Wallet {
	private String name;
    private String pin;
	private String age;
	private String gender;
	private long accId;
	private String address;
	private double balance;
	private String accType;
	private String mobile;
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	public void setAccId(long accId) {
		this.accId = accId;
	}
	
	public String getPin() {
		return pin;
	}
	public long getAccId() {
		return accId;
	}
	public Wallet() {
		super();
	}
	public Wallet(long accId,String name, String accType, String mobile,String age,String gender, String pin, String address, double balance) {
		super();
		this.name = name;
		this.accId=accId;
		this.pin=pin;
		this.address = address;
		this.balance = balance;
		this.accType = accType;
		this.mobile = mobile;
		this.age=age;
		this.gender=gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getBalance() {
		return (long) balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	/*public String toString() {
		return "Customer Name [id=" + name + ", Account Number=" + accId + ", Balance="
				+  + "]";
	}*/

}
